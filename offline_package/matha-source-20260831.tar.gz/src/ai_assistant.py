# -*- coding: utf-8 -*-
"""
Matha AI Assistant — 小白友好的数学计算助手

功能：
  1. 自然语言 → Matha 代码自动生成
  2. 多步骤任务分解（AI 辅助规划）
  3. 小白友好错误解释（非技术语言）
  4. 数学概念讲解 + 例题
  5. 待办事项管理
  6. 跨平台（Web/PWA/Electron）
"""
from __future__ import annotations
import re
import json
import math
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Optional
from enum import Enum

# 模块级调试日志
_logger = logging.getLogger("matha.ai")

# ── 新功能模块导入 ─────────────────────────────────────────────────────────
try:
    from src.symbolic import symbol_expr, simplify_expr, diff_expr, eval_expr, ast_to_dict, SymbolicParser
    from src.ffi import get_ffi, MathaFFIBridge
    from src.multi_paradigm import MultiParadigmEngine, paradigm_compute, get_paradigm_engine
    from src.symbol_codegen import MathaCodeGen, get_codegen, codegen_python, codegen_javascript, codegen_c
    from src.math_driver import MathDriverManager, get_driver_manager
    _NEW_MODULES_LOADED = True
except ImportError as e:
    _logger.warning(f"  新功能模块导入失败: {e}")
    _NEW_MODULES_LOADED = False

# ============================================================
# 意图分类（小白友好版）
# ============================================================

class IntentType(str, Enum):
    算术 = "arithmetic"
    数学函数 = "math_func"
    统计 = "statistics"
    字符串 = "string"
    数组 = "array"
    物理 = "physics"
    工程 = "engineering"
    条件 = "conditional"
    循环 = "loop"
    单位换算 = "unit_convert"
    素数因数 = "number_theory"
    三角函数 = "trig"
    概率统计 = "probability"
    数列 = "sequence"
    几何 = "geometry"
    财务 = "finance"
    烹饪 = "cooking"
    时间计算 = "time_calc"
    配置浓度 = "concentration"
    向量矩阵 = "vector_matrix"
    微积分 = "calculus"
    统计概率 = "stats_prob"
    离散数学 = "discrete"
    应用数学 = "applied_math"
    未知 = "unknown"


@dataclass
class Step:
    """任务分解后的单步。"""
    description: str       # 人类可读
    matha_code: str        # 生成的 Matha 代码
    explanation: str       # 小白解释（为什么这样做）


@dataclass
class Task:
    """待办事项。"""
    id: str
    title: str
    status: str = "pending"  # pending / doing / done
    steps: list[Step] = field(default_factory=list)
    result: Any = None
    error: str = ""
    created_at: float = field(default_factory=time.time)


@dataclass
class ChatMessage:
    """对话消息。"""
    role: str           # "user" | "assistant" | "system"
    content: str
    type: str = "text"  # text / code / math / error / task
    timestamp: float = field(default_factory=time.time)


# ============================================================
# 小白友好意图解析器
# ============================================================

class FriendlyIntentParser:
    """
    将自然语言分解为步骤，生成 Matha 代码，并用小白语言解释。

    工作流程：
      用户输入 → 意图分类 → 参数提取 → 步骤分解 → 代码生成 → 执行 → 结果解释
    """

    # 关键词映射表（用于分类）
    KEYWORD_MAP = {
        IntentType.算术: [
            "加", "减", "乘", "除",
            "+", "-", "×", "÷", "*", "/",
        ],
        IntentType.数学函数: [
            "平方", "立方", "开方", "根号", "幂", "指数",
            "对数", "log", "ln", "绝对值",
        ],
        IntentType.统计: [
            "平均", "均值", "中位数", "标准差", "方差",
            "最大值", "最小值", "求和", "统计", "百分比",
        ],
        IntentType.字符串: [
            "字符串", "文字", "文本", "反转", "拼接", "截取",
            "替换", "查找", "长度", "字数",
        ],
        IntentType.数组: [
            "数组", "列表", "排序", "过滤", "查找", "去重",
            "拆分", "合并", "切片",
        ],
        IntentType.物理: [
            "速度", "加速度", "位移", "力", "质量", "重量",
            "能量", "功", "功率", "压强", "密度",
            "自由落体", "平抛", "斜抛", "圆周",
        ],
        IntentType.工程: [
            "应力", "应变", "惯性矩", "扭矩", "扭转",
            "弯曲", "梁", "轴", "材料", "安全系数",
        ],
        IntentType.三角函数: [
            "sin", "cos", "tan", "正弦", "余弦", "正切",
            "弧度", "角度", "π", "pi",
        ],
        IntentType.素数因数: [
            "素数", "质数", "因数", "因子", "阶乘",
            "最大公约", "最小公倍", "分解",
        ],
        IntentType.单位换算: [
            "换算", "转换", "千米", "米", "厘米", "毫米",
            "千克", "克", "吨", "摄氏度", "华氏度",
            "秒", "分", "小时", "天", "毫秒",
        ],
    }

    # ============================================================
    # 常识知识库（解决"不懂变通"和"冷门应用"问题）
    # ============================================================

    # 近义词/俗语映射表
    SYNONYM_MAP: dict[str, list[str]] = {
        "加": ["加", "加上", "加起来", "求和", "合计", "一共", "添", "并"],
        "减": ["减", "减去", "差", "少了", "剩下", "扣", "去掉"],
        "乘": ["乘", "乘以", "的倍", "几倍", "翻倍", "扩大", "乘积"],
        "除": ["除", "除以", "除法", "平均", "分成", "份", "均分"],
        "算": ["算", "计算", "求", "得", "等于", "多少", "结果", "答案"],
        "素数": ["素数", "质数", "质因数", "因数分解", "素因数"],
        "阶乘": ["阶乘", "!", "连乘"],
        "平均": ["平均", "平均值", "均值", "平均数"],
        "平方": ["平方", "平方数", "二次方", "自乘"],
        "开方": ["开方", "平方根", "根号", "开根", "反平方"],
        "单位": ["换算", "转换", "换算成", "变成"],
        "下落": ["下落", "落下", "掉下来", "扔下去", "自由下落"],
        "射程": ["射程", "飞多远", "飞多高", "落点", "飞行距离"],
        "打折": ["打折", "折扣", "打X折", "优惠", "降价", "贵了", "便宜了", "贵多少", "便宜多少", "满减"],
        "利息": ["利息", "单利", "复利", "利滚利", "年化利率", "存款利率", "贷款利率"],
        "面积": ["面积", "平方", "平方米", "平方厘米", "平方千米", "亩"],
        "概率": ["概率", "可能性", "几率", "概率论", "期望", "期望值"],
        "数列": ["等差", "等比", "数列", "递推", "通项", "求和"],
        "浓度": ["浓度", "配比", "稀释", "溶质", "溶液", "百分比浓度"],
        "配速": ["配速", "每公里", "每分钟", "跑速", "时速"],
        "体积": ["体积", "容积", "升", "毫升", "立方米", "立方厘米"],
        "凑整": ["凑整", "补齐", "差额", "盈亏", "盈了", "亏了"],
        "三角": ["正弦", "余弦", "正切", "cot", "csc", "sec", "反三角"],
        "单位": ["里", "丈", "尺", "寸", "亩", "公顷", "英里", "英尺", "磅", "盎司", "加仑", "焦耳", "瓦特", "马力"],
    }

    # 冷门/变体表达 → 标准意图映射
    VARIATION_MAP: dict[str, IntentType] = {
        # 算术变体
        "帮我算一下": IntentType.算术, "算算": IntentType.算术,
        "怎么算": IntentType.算术, "等于几": IntentType.算术,
        "是多少": IntentType.算术,
        "结果是": IntentType.算术, "求结果": IntentType.算术,
        # 加法变体
        "一共有": IntentType.算术, "总共": IntentType.算术,
        "合计": IntentType.算术, "加起来": IntentType.算术,
        "总共多少": IntentType.算术, "全部加起来": IntentType.算术,
        # 减法变体
        "剩下多少": IntentType.算术, "还差": IntentType.算术,
        "少了多少": IntentType.算术, "相差": IntentType.算术,
        # 乘法变体
        "几倍": IntentType.算术, "翻倍": IntentType.算术,
        "三倍": IntentType.算术, "乘以": IntentType.算术,
        # 除法变体
        "平均分成": IntentType.算术, "一人分": IntentType.算术,
        "每份": IntentType.算术, "一半": IntentType.算术,
        "二分之一": IntentType.算术, "对折": IntentType.算术,
        "对折再对折": IntentType.算术,
        # 统计变体
        "这组数": IntentType.统计, "这些数": IntentType.统计,
        "数据": IntentType.统计, "统计数据": IntentType.统计,
        "最大": IntentType.统计, "最小": IntentType.统计,
        "极差": IntentType.统计, "方差": IntentType.统计, "中位数": IntentType.统计,
        # 物理变体
        "掉下去": IntentType.物理, "扔出去": IntentType.物理,
        "抛出去": IntentType.物理, "飞行": IntentType.物理,
        "速度": IntentType.物理, "加速度": IntentType.物理,
        # 数论变体
        "判断": IntentType.素数因数, "是不是": IntentType.素数因数,
        "能不能整除": IntentType.素数因数, "因数": IntentType.素数因数,
        "因子": IntentType.素数因数, "分解": IntentType.素数因数, "整除": IntentType.素数因数,
        # 三角函数变体
        "正弦": IntentType.三角函数, "余弦": IntentType.三角函数, "正切": IntentType.三角函数,
        # 数学函数变体
        "根号": IntentType.数学函数, "平方根": IntentType.数学函数,
        "立方根": IntentType.数学函数, "对数": IntentType.数学函数,
        "指数": IntentType.数学函数, "幂": IntentType.数学函数,
        "绝对值": IntentType.数学函数, "正负": IntentType.数学函数,
        "开根": IntentType.数学函数,
        # 单位换算变体
        "多少米": IntentType.单位换算, "多少千米": IntentType.单位换算,
        "多少克": IntentType.单位换算, "多少千克": IntentType.单位换算,
        "多少公斤": IntentType.单位换算, "多少吨": IntentType.单位换算,
        "多少华氏度": IntentType.单位换算, "多少摄氏度": IntentType.单位换算,
        "多少毫升": IntentType.单位换算, "多少升": IntentType.单位换算,
        "等于多少米": IntentType.单位换算, "等于多少千米": IntentType.单位换算,
        "等于多少克": IntentType.单位换算, "等于多少千克": IntentType.单位换算,
        "等于多少升": IntentType.单位换算, "等于多少毫升": IntentType.单位换算,
        "等于多少分": IntentType.单位换算, "等于多少小时": IntentType.单位换算,
        "等于多少天": IntentType.单位换算,
        "等于多少秒": IntentType.单位换算, "等于多少毫秒": IntentType.单位换算,
        # 冷门算术表达
        "凑整": IntentType.算术, "补齐": IntentType.算术,
        "差额": IntentType.算术, "差多少": IntentType.算术,
        "盈亏": IntentType.算术, "赚了多少": IntentType.算术,
        "亏了多少": IntentType.算术, "贵了多少": IntentType.算术,
        "便宜多少": IntentType.算术, "贵了": IntentType.算术, "便宜了": IntentType.算术,
        "打八折": IntentType.算术, "打七折": IntentType.算术,
        "打九折": IntentType.算术, "打折": IntentType.算术,
        "翻两番": IntentType.算术, "翻了三番": IntentType.算术,
        # 冷门统计表达
        "排第几": IntentType.统计, "排名第几": IntentType.统计,
        "第几名": IntentType.统计, "最高分": IntentType.统计, "最低分": IntentType.统计,
        "众数": IntentType.统计, "占比": IntentType.统计, "比例": IntentType.统计,
        "取整": IntentType.算术, "取余": IntentType.算术,
        "求余": IntentType.算术, "模运算": IntentType.算术,
        # 冷门物理表达
        "摔下来": IntentType.物理, "砸下来": IntentType.物理,
        "掉到地上": IntentType.物理, "扔多远": IntentType.物理,
        "多快": IntentType.物理, "跑多快": IntentType.物理,
        # 冷门数论表达
        "质因数分解": IntentType.素数因数, "分解质因数": IntentType.素数因数,
        "公约数": IntentType.素数因数, "公倍数": IntentType.素数因数,
        # 冷门三角表达
        "cot": IntentType.三角函数, "csc": IntentType.三角函数, "sec": IntentType.三角函数,
        "arcsin": IntentType.三角函数, "arccos": IntentType.三角函数, "arctan": IntentType.三角函数,
        # 概率表达
        "概率": IntentType.概率统计, "几率": IntentType.概率统计, "期望": IntentType.概率统计,
        "期望值": IntentType.概率统计, "可能性": IntentType.概率统计,
        # 数列表达
        "等差": IntentType.数列, "等比": IntentType.数列,
        "等差数列": IntentType.数列, "等比数列": IntentType.数列,
        # 几何表达
        "面积": IntentType.几何, "周长": IntentType.几何,
        "长方形面积": IntentType.几何, "圆的面积": IntentType.几何,
        # 财务表达
        "单利": IntentType.财务, "复利": IntentType.财务,
        "利息": IntentType.财务, "年利率": IntentType.财务,
        "存款利率": IntentType.财务, "贷款利率": IntentType.财务,
        # 浓度表达
        "浓度": IntentType.配置浓度, "配比": IntentType.配置浓度,
        "稀释": IntentType.配置浓度, "溶质": IntentType.配置浓度,
        # 时间计算表达
        "配速": IntentType.时间计算, "每公里": IntentType.时间计算,
        "时速": IntentType.时间计算, "倒计时": IntentType.时间计算,
        # 冷门单位换算
        "多少尺": IntentType.单位换算, "多少丈": IntentType.单位换算,
        "多少里": IntentType.单位换算, "多少寸": IntentType.单位换算,
        "多少亩": IntentType.单位换算, "多少公顷": IntentType.单位换算,
        # 向量矩阵表达
        "向量": IntentType.向量矩阵, "矢量": IntentType.向量矩阵,
        "矩阵": IntentType.向量矩阵, "行列式": IntentType.向量矩阵,
        # 微积分表达
        "导数": IntentType.微积分, "微分": IntentType.微积分,
        "积分": IntentType.微积分, "极限": IntentType.微积分,
        "瞬时变化率": IntentType.微积分, "切线斜率": IntentType.微积分,
        # 统计概率表达
        "方差": IntentType.统计概率, "标准差": IntentType.统计概率,
        "排列": IntentType.统计概率, "组合": IntentType.统计概率,
        "正态分布": IntentType.统计概率, "概率分布": IntentType.统计概率,
        "期望": IntentType.统计概率, "期望值": IntentType.统计概率,
        # 离散数学表达
        "最大公约数": IntentType.离散数学, "最小公倍数": IntentType.离散数学,
        "质因数": IntentType.离散数学, "质因数分解": IntentType.离散数学,
        "因数": IntentType.离散数学, "因子": IntentType.离散数学,
        # 应用数学表达
        "百分比": IntentType.应用数学, "百分数": IntentType.应用数学,
        "比例": IntentType.应用数学, "勾股定理": IntentType.应用数学,
        "幂运算": IntentType.应用数学, "对数": IntentType.应用数学,
        "阶乘": IntentType.应用数学, "绝对值": IntentType.应用数学,
        "速度": IntentType.应用数学, "距离": IntentType.应用数学,
        "工作问题": IntentType.应用数学, "合作完成": IntentType.应用数学,
        "等差数列求和": IntentType.应用数学, "等比数列求和": IntentType.应用数学,
        "多少平方公里": IntentType.单位换算, "多少英里": IntentType.单位换算,
        "多少英尺": IntentType.单位换算, "多少英寸": IntentType.单位换算,
        "多少磅": IntentType.单位换算, "多少盎司": IntentType.单位换算,
        "多少加仑": IntentType.单位换算, "多少海里": IntentType.单位换算,
        "多少光年": IntentType.单位换算, "多少焦耳": IntentType.单位换算,
        "多少瓦特": IntentType.单位换算, "多少牛顿": IntentType.单位换算,
        "多少马力": IntentType.单位换算, "多少卡路里": IntentType.单位换算,
        "等于多少尺": IntentType.单位换算, "等于多少丈": IntentType.单位换算,
        "等于多少里": IntentType.单位换算, "等于多少磅": IntentType.单位换算,
        "等于多少盎司": IntentType.单位换算, "等于多少英里": IntentType.单位换算,
    }

    # 生活常识推理规则
    COMMONSENSE_RULES: list[dict] = [
        {"pattern": r"\d+\s*(半|一半|二分之一)", "intent": IntentType.算术, "reason": "一半→除法"},
        {"pattern": r"(\d+)\s*(倍|倍)", "intent": IntentType.算术, "reason": "倍→乘法"},
        {"pattern": r"(\d+)\s*(加|加上|加起来)", "intent": IntentType.算术, "reason": "加→加法"},
        {"pattern": r"(\d+)\s*(减|减去|减掉)", "intent": IntentType.算术, "reason": "减→减法"},
        {"pattern": r"(\d+)\s*(平方|自乘)", "intent": IntentType.数学函数, "reason": "平方→平方运算"},
        {"pattern": r"(\d+)\s*(开方|根号|开根)", "intent": IntentType.数学函数, "reason": "开方→平方根"},
        {"pattern": r"自由落体\s*\d+", "intent": IntentType.物理, "reason": "自由落体→物理"},
        {"pattern": r"(\d+)\s*(秒|秒钟).*?(等于|多少|换算)", "intent": IntentType.单位换算, "reason": "秒→单位换算优先于物理"},
        {"pattern": r"(\d+)\s*(秒|秒钟)", "intent": IntentType.物理, "reason": "秒→物理时间"},
        {"pattern": r"(\d+)\s*(米|公尺)", "intent": IntentType.单位换算, "reason": "米→单位换算"},
        {"pattern": r"(\d+)\s*(到|至)\s*(\d+)\s*(的)?\s*(素数|质数)", "intent": IntentType.素数因数, "reason": "范围+素数"},
        {"pattern": r"\d+\s*的?\s*阶乘", "intent": IntentType.素数因数, "reason": "阶乘→数论(高权重)", "weight": 5.0},
        {"pattern": r"\d+\s*的?\s*(因数|因子)", "intent": IntentType.素数因数, "reason": "因数"},
        {"pattern": r"\d+\s*的?\s*(平方根|根号)", "intent": IntentType.数学函数, "reason": "平方根"},
        {"pattern": r"\d+\s*的?\s*(次方|幂|指数)", "intent": IntentType.数学函数, "reason": "次方→幂运算"},
        {"pattern": r"\d+\s*的?\s*(次方|幂|指数).*?(等于|几|多少)", "intent": IntentType.数学函数, "reason": "次方+等于→幂运算优先"},
        {"pattern": r"\d+\s*(平均|均值)", "intent": IntentType.统计, "reason": "平均→统计"},
        {"pattern": r"\d+\s*(对折|对折再)", "intent": IntentType.算术, "reason": "对折→除法/乘法"},
        {"pattern": r"\b(sin|cos|tan)\s*\(", "intent": IntentType.三角函数, "reason": "英文三角函数"},
        {"pattern": r"(sin|cos|tan)\s*\(", "intent": IntentType.三角函数, "reason": "英文三角函数(宽)"},
        {"pattern": r"(abs|sqrt|log)\s*\(", "intent": IntentType.数学函数, "reason": "英文函数名"},
        {"pattern": r".*(次方|幂|指数).*", "intent": IntentType.数学函数, "reason": "含次方词优先数学函数"},
        # 冷门算术
        {"pattern": r".*(打折|折扣).*\d+", "intent": IntentType.算术, "reason": "打折→算术"},
        {"pattern": r".*(翻(fan)?(番|一番)).*", "intent": IntentType.算术, "reason": "翻番→乘法"},
        {"pattern": r".*(赚|亏|贵|便宜)(了|多少).*", "intent": IntentType.算术, "reason": "盈亏/价差→算术"},
        {"pattern": r".*(凑|补齐|差额).*", "intent": IntentType.算术, "reason": "凑整→算术"},
        # 冷门物理
        {"pattern": r".*(摔|砸|掉|落).*(下来|到).*", "intent": IntentType.物理, "reason": "摔落→自由落体"},
        {"pattern": r".*(扔|抛).*(多远|多高|出去).*", "intent": IntentType.物理, "reason": "抛射→物理"},
        # 冷门数论
        {"pattern": r".*(质因数|分解质因数).*", "intent": IntentType.素数因数, "reason": "质因数分解"},
        {"pattern": r".*(公约数|公倍数).*", "intent": IntentType.素数因数, "reason": "公约数公倍数"},
        # 冷门统计
        {"pattern": r".*(排|排名|第几).*", "intent": IntentType.统计, "reason": "排名→统计"},
        {"pattern": r".*(最高|最低|最大|最小).*", "intent": IntentType.统计, "reason": "极值→统计"},
        {"pattern": r".*(占比|比例|百分).*", "intent": IntentType.统计, "reason": "占比→统计"},
        {"pattern": r".*(众数|中位数).*", "intent": IntentType.统计, "reason": "统计量"},
        # 冷门单位换算
        {"pattern": r".*(尺|丈|里|寸|亩|公顷|英里|英尺|英寸|磅|盎司|加仑|海里|焦耳|瓦特|牛顿|马力|卡路里).*", "intent": IntentType.单位换算, "reason": "冷门单位"},
        {"pattern": r".*(光年|天文单位).*", "intent": IntentType.单位换算, "reason": "天文单位"},
        {"pattern": r".*(公升|公升|毫升).*", "intent": IntentType.单位换算, "reason": "体积单位"},
        # 新意图类型规则（高权重优先）
        {"pattern": r".*(概率|几率|可能性).*", "intent": IntentType.概率统计, "reason": "概率表达", "weight": 5.0},
        {"pattern": r".*(期望|期望值).*", "intent": IntentType.概率统计, "reason": "期望值", "weight": 5.0},
        {"pattern": r".*(等差|等比).*数列.*", "intent": IntentType.数列, "reason": "数列表达", "weight": 5.0},
        {"pattern": r".*(面积|周长|半径|边长).*", "intent": IntentType.几何, "reason": "几何计算", "weight": 5.0},
        {"pattern": r".*(利息|单利|复利|年利率|存款|理财|银行).*", "intent": IntentType.财务, "reason": "财务计算", "weight": 5.0},
        {"pattern": r".*(浓度|配比|稀释|溶质|溶在|溶\d).*", "intent": IntentType.配置浓度, "reason": "浓度计算", "weight": 5.0},
        {"pattern": r".*(配速|每公里|时速|倒计时|跑.*公里).*", "intent": IntentType.时间计算, "reason": "时间计算", "weight": 6.0},
        {"pattern": r"\d+\s*的?\s*(平方|立方).*", "intent": IntentType.数学函数, "reason": "平方/立方→数学函数", "weight": 5.0},
        {"pattern": r".*(厘).*", "intent": IntentType.财务, "reason": "厘→利息单位"},
        # 向量矩阵规则
        {"pattern": r".*(向量|矢量|矩阵|行列式).*", "intent": IntentType.向量矩阵, "reason": "向量矩阵运算", "weight": 5.0},
        # 微积分规则
        {"pattern": r".*(导数|微分|积分|极限|瞬时变化率|切线斜率).*", "intent": IntentType.微积分, "reason": "微积分运算", "weight": 5.0},
        # 统计概率规则
        {"pattern": r".*(方差|标准差|排列|组合|正态分布|概率分布).*", "intent": IntentType.统计概率, "reason": "统计概率运算", "weight": 5.0},
        # 离散数学规则
        {"pattern": r".*(最大公约数|最小公倍数|质因数分解).*", "intent": IntentType.离散数学, "reason": "数论运算", "weight": 5.0},
        # 应用数学规则
        {"pattern": r".*(百分比|百分数|勾股定理|幂运算|对数法则).*", "intent": IntentType.应用数学, "reason": "应用数学", "weight": 5.0},
        {"pattern": r".*(工作问题|合作完成|效率相加).*", "intent": IntentType.应用数学, "reason": "工程应用数学", "weight": 5.0},
        {"pattern": r".*(等差数列求和|等比数列求和).*", "intent": IntentType.应用数学, "reason": "数列求和", "weight": 5.0},
    ]

    # 错误解释模板
    ERROR_EXPLANATIONS = {
        "未定义变量": {
            "小白解释": "你用到了一个还没有定义的数。需要先告诉系统它是多少。",
            "怎么修": "在前面加一行声明，比如：@：x=10",
            "例子": "@：x=5\n#1: x + 3 = 结果\n#1: [结果]  →  输出 8",
        },
        "未定义函数": {
            "小白解释": "你调用了一个还没定义的公式。需要先定义它。",
            "怎么修": "加一行函数定义，比如：func 平方(x)->Int=(x)=>x*x",
            "例子": "func 平方(x)->Int=(x)=>x*x\n#1: 平方(5) = 结果\n#1: [结果]  →  输出 25",
        },
        "除零错误": {
            "小白解释": "你试图除以 0，这在数学上没有意义。",
            "怎么修": "检查除数（分母）是否可能为 0。",
            "例子": "如果除数是变量，先判断：if 除数 != 0, 再计算",
        },
        "取模除零错误": {
            "小白解释": "取余运算（%）的除数不能为 0。",
            "怎么修": "检查 % 右边的数是否为 0。",
            "例子": "确保 a % b 中 b ≠ 0",
        },
        "JSON 解析失败": {
            "小白解释": "你输入的内容格式不对，系统无法理解。",
            "怎么修": "检查括号是否配对，逗号是否正确。",
            "例子": "用 [] 包裹数组元素，用 {} 包裹对象",
        },
        "ParseError": {
            "小白解释": "代码语法有误，请检查符号和括号。",
            "怎么修": "Matha 代码需要用特定的符号格式。",
            "例子": "正确格式：#1: a + b = 结果\n错误：#1: a + b",
        },
    }

    def __init__(self):
        self._tasks: dict[str, Task] = {}
        self._messages: list[ChatMessage] = []
        self._learned_patterns: dict[str, IntentType] = {}  # 学习用户表达
        # ── 成长记忆系统 ────────────────────────────────
        self._failure_log: list[dict] = []       # 执行失败记录
        self._correction_log: list[dict] = []    # 用户纠正记录
        self._growth_log: list[dict] = []        # 成长日志
        self._known_expressions: dict[str, str] = {}  # 已知表达→意图映射

    # ── 意图分类 ─────────────────────────────────────────────

    def classify(self, text: str) -> tuple[IntentType, float]:
        """根据关键词分类，返回 (类型, 置信度)。

        增强策略：
          1. 精确关键词匹配（原有逻辑）
          2. 变体表达匹配（VARIATION_MAP）
          3. 常识推理匹配（COMMONSENSE_RULES）
          4. 数字特征推断（fallback）
          5. 用户学习记忆（_learned_patterns）
        """
        text_lower = text.lower()
        _logger.debug("=== 意图分类开始: '%s' ===", text)
        scores: dict[IntentType, float] = {}

        # ── 策略1：精确关键词匹配 ────────────────────────────
        for intent_type, keywords in self.KEYWORD_MAP.items():
            score = 0.0
            sorted_kw = sorted(keywords, key=len, reverse=True)
            for kw in sorted_kw:
                if kw in text_lower:
                    weight = 3.0 if len(kw) >= 3 else 2.0 if len(kw) == 2 else 1.0
                    score += weight
                    _logger.debug("  [策略1-关键词] 匹配 '%s' → %s (+%.1f)", kw, intent_type.value, weight)
            if score > 0:
                scores[intent_type] = scores.get(intent_type, 0) + score
                _logger.debug("  [策略1] %s 得分 %.1f", intent_type.value, score)

        # ── 策略2：变体表达匹配 ────────────────────────────
        for variant, intent in self.VARIATION_MAP.items():
            if variant in text_lower:
                scores[intent] = scores.get(intent, 0) + 5.0
                _logger.debug("  [策略2-变体] 匹配 '%s' → %s (+5.0)", variant, intent.value)

        # ── 策略3：常识推理匹配 ────────────────────────────
        for rule in self.COMMONSENSE_RULES:
            if re.search(rule["pattern"], text, re.IGNORECASE):
                rule_weight = rule.get("weight", 4.0)
                scores[rule["intent"]] = scores.get(rule["intent"], 0) + rule_weight
                _logger.debug("  [策略3-常识] 规则 %s 匹配: %s (+%.1f) [reason=%s]",
                             rule["pattern"], rule["intent"].value, rule_weight, rule["reason"])

        # ── 策略4：用户学习记忆 ────────────────────────────
        for pattern, intent in self._learned_patterns.items():
            if pattern in text_lower:
                scores[intent] = scores.get(intent, 0) + 6.0
                _logger.debug("  [策略4-学习] 记忆模式 '%s' → %s (+6.0)", pattern, intent.value)

        # ── 策略5：数字特征推断（fallback） ────────────────
        nums = self.extract_numbers(text)
        if not scores:
            inferred = self._infer_from_numbers(text, nums)
            if inferred:
                scores[inferred] = 2.0
                _logger.debug("  [策略5-fallback] 数字推断 → %s (+2.0) [nums=%s]",
                             inferred.value, nums)

        if not scores:
            _logger.debug("=== 意图分类结束: 未知 (无匹配策略) ===")
            return IntentType.未知, 0.1

        best_type = max(scores, key=scores.get)
        total = sum(scores.values())
        confidence = scores[best_type] / total * 0.9 + 0.1
        _logger.debug("=== 意图分类结束: %s 置信度 %.1f%% 得分 %s ===",
                      best_type.value, confidence * 100, dict(scores))
        return best_type, min(confidence, 1.0)

    def _infer_from_numbers(self, text: str, nums: list[float]) -> Optional[IntentType]:
        """从数字特征推断意图（兜底策略）。"""
        text_lower = text.lower()
        if len(nums) >= 2:
            # 多个数字 → 算术运算可能性高
            return IntentType.算术
        if len(nums) == 1:
            n = nums[0]
            # 大数 → 可能素数/阶乘
            if n >= 10 and n <= 1000:
                if any(kw in text_lower for kw in ["判断", "是否", "能不能"]):
                    return IntentType.素数因数
                if any(kw in text_lower for kw in ["因数", "因子", "分解"]):
                    return IntentType.素数因数
            if n >= 1 and n <= 20:
                if any(kw in text_lower for kw in ["阶乘", "!"]):
                    return IntentType.素数因数
            # 小数 → 可能是物理量
            if n > 0 and n < 100:
                if any(kw in text_lower for kw in ["秒", "时间", "速度", "下落"]):
                    return IntentType.物理
                if any(kw in text_lower for kw in ["度", "角度", "sin", "cos", "tan"]):
                    return IntentType.三角函数
        return None

    def learn(self, text: str, intent: IntentType) -> None:
        """学习用户的表达方式，提升未来分类准确度。"""
        # 提取文本中的关键词模式
        words = re.findall(r'[\u4e00-\u9fa5]+', text)
        for word in words:
            if len(word) >= 2:
                self._learned_patterns[word] = intent
        # 持久化到已知表达库
        self._known_expressions[text] = intent.value
        _logger.info(f"学习新模式: '{text}' → {intent.value}")
        self._growth_log.append({
            "action": "learn", "text": text,
            "intent": intent.value, "time": time.time()
        })
        _logger.info(f"  [成长] 学习记录已保存，累计 {len(self._growth_log)} 条")

    def record_failure(self, text: str, error: str, intent: IntentType) -> None:
        """记录执行失败，用于后续自动学习修复。"""
        entry = {"text": text, "error": error[:100],
                 "intent": intent.value, "time": time.time()}
        self._failure_log.append(entry)
        _logger.warning(f"  [成长] 记录失败: '{text}' → {error[:50]}")
        self._auto_learn_from_failure(text, error)

    def _auto_learn_from_failure(self, text: str, error: str) -> None:
        """从失败中自动学习，生成修复建议。"""
        if "未定义函数" in error:
            m = re.search(r"[未定义]+(?:函数|变量)?\s*['\"]?([^'\"]+)['\"]?", error)
            if m:
                fn = m.group(1).strip()
                _logger.info(f"  [自动学习] 发现未定义函数: '{fn}'，建议添加内建")
                self._growth_log.append({"action": "auto_learn_func",
                                         "suggestion": fn, "time": time.time()})
        if "未定义变量" in error:
            m = re.search(r"[未定义]+(?:变量)?\s*['\"]?([^'\"]+)['\"]?", error)
            if m:
                var = m.group(1).strip()
                _logger.info(f"  [自动学习] 发现未定义变量: '{var}'，建议添加常量")
                self._growth_log.append({"action": "auto_learn_var",
                                         "suggestion": var, "time": time.time()})

    def record_correction(self, original_text: str, original_intent: str,
                          corrected_intent: str) -> None:
        """记录用户纠正，用于提升分类准确度。"""
        entry = {"original": original_text, "original_intent": original_intent,
                 "corrected_intent": corrected_intent, "time": time.time()}
        self._correction_log.append(entry)
        self._known_expressions[original_text] = corrected_intent
        _logger.info(f"  [成长] 用户纠正: '{original_text}' {original_intent}→{corrected_intent}")
        words = re.findall(r'[\u4e00-\u9fa5]+', original_text)
        for word in words:
            if len(word) >= 2:
                try:
                    self._learned_patterns[word] = IntentType(corrected_intent)
                except ValueError:
                    pass
        self._growth_log.append({"action": "correction", "text": original_text,
                                 "from": original_intent, "to": corrected_intent,
                                 "time": time.time()})

    def get_growth_stats(self) -> dict:
        """返回成长统计数据。"""
        return {
            "total_learned": len(self._learned_patterns),
            "total_failures": len(self._failure_log),
            "total_corrections": len(self._correction_log),
            "total_growth_records": len(self._growth_log),
            "known_expressions": len(self._known_expressions),
            "recent_growth": self._growth_log[-5:] if self._growth_log else []
        }

    # ── 参数提取 ─────────────────────────────────────────────

    def extract_numbers(self, text: str) -> list[float]:
        """从文本中提取所有数字。"""
        return [float(x) for x in re.findall(r'-?\d+\.?\d*', text)]

    def extract_range(self, text: str) -> Optional[tuple[int, int]]:
        """提取范围，如 '1到100' → (1, 100)。"""
        m = re.search(r'(\d+)\s*[到至 till ]\s*(\d+)', text)
        if m:
            return int(m.group(1)), int(m.group(2))
        m = re.search(r'(\d+)\s*到\s*(\d+)', text)
        if m:
            return int(m.group(1)), int(m.group(2))
        return None

    def extract_variable(self, text: str) -> Optional[str]:
        """提取变量名。"""
        # 找中文字符变量名
        m = re.search(r'[\u4e00-\u9fa5]{2,8}', text)
        return m.group(0) if m else None

    # ── 步骤分解（核心：AI 辅助规划）─────────────────────────

    def decompose(self, text: str) -> list[Step]:
        """将自然语言分解为可执行的步骤。"""
        intent_type, confidence = self.classify(text)
        numbers = self.extract_numbers(text)
        rng = self.extract_range(text)

        steps = []

        if intent_type == IntentType.算术:
            _logger.debug("  [decompose] 算术分支: text='%s' nums=%s", text, numbers)
            steps = self._decompose_arithmetic(text, numbers)
        elif intent_type == IntentType.数学函数:
            _logger.debug("  [decompose] 数学函数分支: text='%s' nums=%s", text, numbers)
            steps = self._decompose_math_func(text, numbers)
        elif intent_type == IntentType.统计:
            steps = self._decompose_statistics(text, numbers)
        elif intent_type == IntentType.字符串:
            steps = self._decompose_string(text)
        elif intent_type == IntentType.数组:
            steps = self._decompose_array(text, numbers)
        elif intent_type == IntentType.物理:
            _logger.debug("  [decompose] 物理分支: text='%s' nums=%s", text, numbers)
            steps = self._decompose_physics(text, numbers)
        elif intent_type == IntentType.三角函数:
            steps = self._decompose_trig(text, numbers)
        elif intent_type == IntentType.素数因数:
            steps = self._decompose_number_theory(text, rng, numbers)
        elif intent_type == IntentType.单位换算:
            _logger.debug("  [decompose] 单位换算分支: text='%s' nums=%s", text, numbers)
            steps = self._decompose_unit_convert(text, numbers)
        else:
            _logger.debug("  [decompose] 未知意图，返回引导步骤")
            steps = [Step(
                description="无法理解，请重新描述",
                matha_code="",
                explanation="试试这样说：'计算 3 加 5' 或 '找出 1 到 100 的素数'",
            )]

        return steps

    def _decompose_arithmetic(self, text: str, nums: list[float]) -> list[Step]:
        if len(nums) >= 2:
            op_map = {"加": "+", "减": "-", "乘": "*", "除": "/"}
            op = "+"
            for kw, sym in op_map.items():
                if kw in text:
                    op = sym
                    break
            # 补充："倍" → 乘法
            if op == "+" and "倍" in text:
                op = "*"
            return [Step(
                description=f"计算 {nums[0]} {op} {nums[1]}",
                matha_code=f"#1：[{nums[0]} {op} {nums[1]}]",
                explanation=f"{nums[0]} 和 {nums[1]} 做 {'加法' if op=='+' else '减法' if op=='-' else '乘法' if op=='*' else '除法'} → 结果",
            )]
        # 单数字 + 倍 → 乘法（自身倍）
        if len(nums) == 1 and "倍" in text:
            n = nums[0]
            return [Step(f"计算 {n} 的倍",
                          f"#1：[{n} * {n}]", f"{n} 的倍数 = {n} × {n}")]
        return [Step(
            description="请提供两个数字",
            matha_code="",
            explanation="算术运算需要两个数字，例如：'计算 3 加 5'",
        )]

    def _decompose_math_func(self, text: str, nums: list[float]) -> list[Step]:
        if not nums:
            nums = [0]
        steps = []
        if "平方" in text:
            _logger.debug("  [math_func分解] 检测到平方")
            steps.append(Step("计算平方", f"#1：[{nums[0]} * {nums[0]}]",
                              "平方 = 这个数乘以自己"))
        if "立方" in text:
            _logger.debug("  [math_func分解] 检测到立方")
            steps.append(Step("计算立方", f"#1：[{nums[0]} * {nums[0]} * {nums[0]}]",
                              "立方 = 这个数乘自己三次"))
        if "开方" in text or "根号" in text:
            _logger.debug("  [math_func分解] 检测到开方/根号")
            steps.append(Step("计算平方根", f"#1：[sqrt({nums[0]})]",
                              "平方根 = 哪个数乘自己等于这个数"))
        if "绝对值" in text:
            _logger.debug("  [math_func分解] 检测到绝对值")
            steps.append(Step("计算绝对值", f"#1：[abs({nums[0]})]",
                              "绝对值 = 去掉负号，只看大小"))
        if "阶乘" in text:
            _logger.debug("  [math_func分解] 检测到阶乘")
            n = int(nums[0]) if nums else 5
            steps.append(Step(f"计算 {n} 的阶乘",
                              f"#1：[阶乘({n})]",
                              f"{n}! = {n}×{n-1}×...×1"))
        if "次方" in text:
            if len(nums) >= 2:
                _logger.debug("  [math_func分解] 检测到次方(双数字): base=%s exp=%s", nums[0], nums[1])
                base, exp = nums[0], nums[1]
                steps.append(Step(f"计算 {base} 的 {exp} 次方",
                                  f"#1：[{base} ^ {exp}]",
                                  f"{base}^{exp} = {base ** int(exp) if exp == int(exp) else base ** exp}"))
            elif len(nums) == 1:
                _logger.debug("  [math_func分解] 检测到次方(单数字→平方)")
                n = nums[0]
                steps.append(Step(f"计算 {n} 的平方",
                                  f"#1：[{n} * {n}]", f"{n} 的平方 = {n} × {n}"))
        _logger.debug("  [math_func分解] 生成 %d 步", len(steps))
        return steps or [Step("请选择要计算的函数", "", "可以计算：平方、立方、开方、绝对值、阶乘、次方")]

    def _decompose_statistics(self, text: str, nums: list[float]) -> list[Step]:
        if not nums:
            nums = [1, 2, 3, 4, 5]
        arr = "[" + ", ".join(str(int(x)) if x == int(x) else str(x) for x in nums) + "]"
        steps = []
        if "平均" in text or "均值" in text:
            steps.append(Step("计算平均值", f"#1：[平均值({arr})]",
                              "平均值 = 所有数加起来除以个数"))
        if "求和" in text or "总和" in text:
            steps.append(Step("计算总和", f"#1：[求和({arr})]",
                              "总和 = 把所有数加起来"))
        if "最大" in text:
            steps.append(Step("找最大值", f"#1：[max({arr})]",
                              "最大值 = 这组数中最大的那个"))
        if "最小" in text:
            steps.append(Step("找最小值", f"#1：[min({arr})]",
                              "最小值 = 这组数中最小的那个"))
        if "排序" in text:
            steps.append(Step("排序", f"#1：[排序({arr})]",
                              "排序 = 从小到大排列"))
        if "中位数" in text:
            steps.append(Step("计算中位数", f"#1：[排序({arr})]",
                              "中位数 = 排序后最中间的那个数"))
        return steps or [Step("请指定统计方式", "", "可以：平均、求和、最大、最小、排序、中位数")]

    def _decompose_string(self, text: str) -> list[Step]:
        # 简单示例
        return [Step("字符串操作", f"#1: StrReverse('hello') = 结果\n#1: [结果]",
                      "字符串反转 = 把文字倒过来写")]

    def _decompose_array(self, text: str, nums: list[float]) -> list[Step]:
        if not nums:
            nums = [3, 1, 2]
        steps = []
        if "排序" in text:
            steps.append(Step("数组排序",
                              f"#1: ArraySort([{','.join(map(str, nums))}]) = 结果\n#1: [结果]",
                              "排序 = 从小到大排列"))
        if "过滤" in text or "查找" in text:
            steps.append(Step("数组查找",
                              f"#1: ArrayFind([{','.join(map(str, nums))}], 3) = 结果\n#1: [结果]",
                              "查找 = 在数组中找某个数"))
        if "去重" in text:
            steps.append(Step("数组去重",
                              f"#1: ArrayUnique([{','.join(map(str, nums))}]) = 结果\n#1: [结果]",
                              "去重 = 去掉重复的数"))
        if "反转" in text:
            steps.append(Step("数组反转",
                              f"#1: ArrayReverse([{','.join(map(str, nums))}]) = 结果\n#1: [结果]",
                              "反转 = 倒过来排列"))
        return steps or [Step("数组操作",
                              f"#1: ArraySort([{','.join(map(str, nums))}]) = 结果\n#1: [结果]",
                              "支持：排序、查找、去重、反转")]

    def _decompose_physics(self, text: str, nums: list[float]) -> list[Step]:
        steps = []
        if "自由落体" in text or "下落" in text:
            if len(nums) >= 1:
                t = nums[0]
                g = 9.80665
                steps.append(Step("自由落体计算",
                                  f"#1：[运动_自由落体位移({t})]",
                                  f"自由落体：从 {t} 秒高处落下，重力加速度 g={g} m/s²"))
            else:
                steps.append(Step("自由落体", "", "请提供下落时间（秒），如：'自由落体 3 秒'"))
        if "斜抛" in text or "射程" in text:
            if len(nums) >= 2:
                v0, angle = nums[0], nums[1]
                steps.append(Step("斜抛射程计算",
                                  f"#1：[运动_斜抛射程({v0}, {angle})]",
                                  f"斜抛：初速度 {v0} m/s，角度 {angle}°，计算最远射程"))
        if "匀速" in text:
            if len(nums) >= 2:
                steps.append(Step("匀速运动",
                                  f"#1：[运动_匀速位移({nums[0]}, {nums[1]})]",
                                  f"匀速：速度 {nums[0]} m/s，时间 {nums[1]}s，计算位移"))
        return steps or [Step("物理计算", "", "支持：自由落体、斜抛、匀速运动、匀变速运动")]

    def _decompose_trig(self, text: str, nums: list[float]) -> list[Step]:
        if not nums:
            nums = [0]
        steps = []
        if "sin" in text.lower() or "正弦" in text:
            steps.append(Step("计算 sin", f"#1：[sin({nums[0]})]",
                              "sin(角度) = 这个角度的正弦值（对边/斜边）"))
        if "cos" in text.lower() or "余弦" in text:
            steps.append(Step("计算 cos", f"#1：[cos({nums[0]})]",
                              "cos(角度) = 这个角度的余弦值（邻边/斜边）"))
        if "tan" in text.lower() or "正切" in text:
            steps.append(Step("计算 tan", f"#1：[tan({nums[0]})]",
                              "tan(角度) = 这个角度的正切值（对边/邻边）"))
        return steps or [Step("三角函数", "", "支持：sin、cos、tan（输入弧度）")]

    def _decompose_number_theory(self, text: str, rng: Optional[tuple], nums: list[float]) -> list[Step]:
        _logger.debug("  [数论分解] text='%s' rng=%s nums=%s", text, rng, nums)
        steps = []
        if "阶乘" in text:
            _logger.debug("  [数论分解] 检测到阶乘")
            n = int(nums[0]) if nums else 5
            steps.append(Step(f"计算 {n}! = ?",
                              f"#1：[阶乘({n})]",
                              f"{n}! = {n}×{n-1}×...×1"))
        if "素数" in text or "质数" in text:
            _logger.debug("  [数论分解] 检测到素数(范围=%s)", rng)
            if rng:
                a, b = rng
                steps.append(Step(f"找出 {a} 到 {b} 的素数",
                                  f"#1：[素数筛({b})]",
                                  f"素数 = 只能被 1 和自己整除的数，范围 {a}~{b}"))
            elif nums:
                n = int(nums[0])
                steps.append(Step(f"判断 {n} 是否为素数",
                                  f"#1：[素数判定({n})]",
                                  f"素数判定 = 检查 {n} 是否只能被 1 和自己整除"))
        if "因数" in text or "因子" in text:
            if nums:
                n = int(nums[0])
                steps.append(Step(f"找出 {n} 的因数",
                                  f"#1：[IntFactors({n})]",
                                  f"因数 = 能整除 {n} 的所有正整数"))
        return steps or [Step("数论计算", "", "支持：素数判定、找素数、阶乘、因数分解")]

    def _decompose_unit_convert(self, text: str, nums: list[float]) -> list[Step]:
        _logger.debug("  [单位换算分解] text='%s' nums=%s", text, nums)
        if not nums:
            nums = [1]
        return [Step("单位换算",
                     f"#1: 换算_千米_米({nums[0]}) = 结果\n#1: [结果]",
                     f"{nums[0]} 千米 = ? 米（1千米 = 1000米）")]

    # ── 执行与结果解释 ───────────────────────────────────────

    def execute_steps(self, steps: list[Step], interp) -> list[dict]:
        """执行步骤列表，返回结果。"""
        results = []
        for step in steps:
            if not step.matha_code:
                results.append({"step": step.description, "status": "skip", "result": None})
                continue
            try:
                from src.parser import parse
                from src.interp import Interpreter
                i = Interpreter()
                outputs, _ = i.run(parse(step.matha_code))
                results.append({
                    "step": step.description,
                    "status": "ok",
                    "result": outputs[-1] if outputs else None,
                })
            except Exception as e:
                results.append({
                    "step": step.description,
                    "status": "error",
                    "result": None,
                    "error": str(e),
                })
        return results

    def explain_error(self, error_msg: str) -> dict:
        """将技术错误翻译为小白语言。"""
        for key, info in self.ERROR_EXPLANATIONS.items():
            if key in error_msg:
                return {
                    "what": info["小白解释"],
                    "how": info["怎么修"],
                    "example": info["例子"],
                }
        # 通用错误解释
        return {
            "what": f"出现了一个错误：{error_msg[:80]}",
            "how": "请检查输入的数字或格式是否正确。",
            "example": "试试：'计算 3 加 5'",
        }

    def explain_intent(self, text: str) -> dict:
        """生成完整意图解释。"""
        intent_type, confidence = self.classify(text)
        steps = self.decompose(text)
        return {
            "type": intent_type.value,
            "confidence": round(confidence, 2),
            "steps": [s.description for s in steps],
            "total_steps": len(steps),
        }

    # ── 数学概念讲解 ─────────────────────────────────────────

    MATH_CONCEPTS = {
        "加法": {
            "是什么": "把两个数合在一起，得到总和。",
            "符号": "+",
            "例子": "3 + 5 = 8，表示 3 个苹果加 5 个苹果，一共 8 个苹果。",
            "生活中的例子": "购物结账、计算人数、统计总数。",
        },
        "乘法": {
            "是什么": "相同数重复相加的快捷方式。",
            "符号": "× 或 *",
            "例子": "3 × 5 = 15，就是 3 个 5 相加：5 + 5 + 5 = 15。",
            "生活中的例子": "买多件商品总价、计算面积（长×宽）。",
        },
        "除法": {
            "是什么": "把一个数平均分成若干份。",
            "符号": "÷ 或 /",
            "例子": "15 ÷ 3 = 5，表示 15 平均分成 3 份，每份 5。",
            "生活中的例子": "分蛋糕、算人均费用、速度=距离÷时间。",
        },
        "平方": {
            "是什么": "一个数乘以它自己。",
            "符号": "x² 或 x*x",
            "例子": "5² = 25，即 5 × 5 = 25。",
            "生活中的例子": "正方形面积（边长×边长）。",
        },
        "开方": {
            "是什么": "平方运算的逆运算，找一个数，它的平方等于原数。",
            "符号": "√x",
            "例子": "√25 = 5，因为 5 × 5 = 25。",
            "生活中的例子": "已知面积求正方形边长。",
        },
        "平均值": {
            "是什么": "所有数加起来除以个数，代表整体水平。",
            "符号": "avg = sum / n",
            "例子": "[3, 5, 7] 的平均值 = (3+5+7)/3 = 5。",
            "生活中的例子": "计算平均成绩、平均温度、平均工资。",
        },
        "素数": {
            "是什么": "只能被 1 和自己整除的大于 1 的数。",
            "例子": "2, 3, 5, 7, 11, 13, 17, 19... 是素数。",
            "生活中的例子": "密码学、随机数生成。",
        },
        "三角函数": {
            "是什么": "描述三角形边角关系的函数。",
            "符号": "sin, cos, tan",
            "例子": "sin(90°) = 1，cos(0°) = 1",
            "生活中的例子": "建筑工程、游戏开发、导航定位。",
        },
        "概率": {
            "是什么": "一个事件发生的可能性，用 0 到 1 之间的数表示。",
            "符号": "P(A)",
            "例子": "掷硬币正面朝上的概率 = 1/2 = 0.5",
            "生活中的例子": "天气预报降雨概率、彩票中奖率。",
        },
        "期望值": {
            "是什么": "随机事件的长期平均结果。",
            "符号": "E[X]",
            "例子": "掷骰子的期望值 = (1+2+3+4+5+6)/6 = 3.5",
            "生活中的例子": "保险精算、投资预期收益。",
        },
        "等差数列": {
            "是什么": "后一项减前一项的差是固定值的数列。",
            "符号": "a_n = a_1 + (n-1)d",
            "例子": "2, 5, 8, 11... 公差 d=3，第10项 = 2+(10-1)*3 = 29",
            "生活中的例子": "阶梯定价、等间距种植。",
        },
        "等比数列": {
            "是什么": "后一项除以前一项的比是固定值的数列。",
            "符号": "a_n = a_1 * r^(n-1)",
            "例子": "2, 6, 18, 54... 公比 r=3，第5项 = 2*3^4 = 162",
            "生活中的例子": "细胞分裂、复利增长。",
        },
        "长方形面积": {
            "是什么": "长乘以宽。",
            "符号": "S = 长 × 宽",
            "例子": "长5米宽3米的房间，面积 = 5 × 3 = 15 平方米",
            "生活中的例子": "房间面积、地板面积。",
        },
        "圆的面积": {
            "是什么": "π乘以半径的平方。",
            "符号": "S = πr²",
            "例子": "半径3米的圆形花坛，面积 ≈ 28.27 平方米",
            "生活中的例子": "圆形花坛、披萨面积。",
        },
        "单利": {
            "是什么": "利息只按本金计算，不加入本金复利。",
            "符号": "利息 = 本金 × 利率 × 时间",
            "例子": "存10000元，年利率5%，3年后利息 = 1500元",
            "生活中的例子": "定期存款、国债利息。",
        },
        "复利": {
            "是什么": "利息加入本金继续产生利息，利滚利。",
            "符号": "本利和 = 本金 × (1+利率)^时间",
            "例子": "存10000元，年利率5%，3年后 ≈ 11576元",
            "生活中的例子": "银行存款复利、基金定投。",
        },
        "折扣": {
            "是什么": "原价乘以折扣比例（打X折 = 原价×X/10）。",
            "符号": "折后价 = 原价 × 折扣/10",
            "例子": "原价200元打七折 = 140元",
            "生活中的例子": "商场促销、双十一打折。",
        },
        "配比浓度": {
            "是什么": "溶质质量除以溶液总质量。",
            "符号": "浓度 = 溶质 / (溶质 + 溶剂) × 100%",
            "例子": "10克盐溶在90克水里，浓度 = 10%",
            "生活中的例子": "调制饮料、配制消毒液。",
        },
        "配速": {
            "是什么": "跑每公里所需的时间。",
            "符号": "配速 = 时间 / 距离",
            "例子": "跑10公里用了50分钟，配速 = 5分钟/公里",
            "生活中的例子": "跑步训练、马拉松配速。",
        },
        # ── 初中数学 ───────────────────────────────────────────────────────────
        "百分比": {
            "是什么": "表示一个数是另一个数的百分之几，分母固定为100。",
            "符号": "a% = a/100",
            "例子": "80% = 80/100 = 0.8，200的25% = 200×0.25 = 50",
            "生活中的例子": "折扣计算、成绩换算、税率计算。",
        },
        "比例": {
            "是什么": "两个比相等的式子，表示数量之间的对应关系。",
            "符号": "a:b = c:d → a×d = b×c",
            "例子": "2:3 = 4:6，因为 2×6 = 3×4 = 12",
            "生活中的例子": "地图比例尺、配方调配、缩放图形。",
        },
        "勾股定理": {
            "是什么": "直角三角形中，两直角边的平方和等于斜边的平方。",
            "符号": "a² + b² = c²",
            "例子": "直角边3和4，斜边 = √(9+16) = 5",
            "生活中的例子": "建筑对角线测量、梯子靠墙高度计算。",
        },
        "幂运算": {
            "是什么": "相同因数相乘的简便运算，a的n次方表示n个a相乘。",
            "符号": "aⁿ = a×a×...×a（n个）",
            "例子": "2³ = 2×2×2 = 8，10² = 100",
            "生活中的例子": "复利计算、面积体积单位换算。",
        },
        "对数": {
            "是什么": "已知幂的底数和结果，求指数的运算，是指数运算的逆运算。",
            "符号": "log_b(a) = c → bᶜ = a",
            "例子": "log₂(8) = 3，因为 2³ = 8",
            "生活中的例子": "声音分贝、地震震级、pH值。",
        },
        "阶乘": {
            "是什么": "正整数从1乘到该数的积，记作n!。",
            "符号": "n! = 1×2×...×n",
            "例子": "5! = 1×2×3×4×5 = 120",
            "生活中的例子": "排列组合、概率计算。",
        },
        "绝对值": {
            "是什么": "一个数到原点的距离，非负。",
            "符号": "|a| = a（a≥0），|a| = -a（a<0）",
            "例子": "|-5| = 5，|3| = 3",
            "生活中的例子": "温度差、距离计算。",
        },
        # ── 高中数学 ───────────────────────────────────────────────────────────
        "向量": {
            "是什么": "既有大小又有方向的量，用坐标表示。",
            "符号": "v = (x, y)，|v| = √(x²+y²)",
            "例子": "v=(3,4)，|v| = √(9+16) = 5",
            "生活中的例子": "速度、力的合成、游戏物理引擎。",
        },
        "矩阵": {
            "是什么": "按行和列排列的数表，可进行加、乘、转置等运算。",
            "符号": "A = [[a,b],[c,d]]",
            "例子": "[[1,2],[3,4]] × [[5,6],[7,8]] = [[19,22],[43,50]]",
            "生活中的例子": "图像变换、3D渲染、线性方程组求解。",
        },
        "导数": {
            "是什么": "函数在某点的瞬时变化率，即切线斜率。",
            "符号": "f'(x) = lim[Δx→0] (f(x+Δx)-f(x))/Δx",
            "例子": "f(x)=x²，f'(x)=2x，f'(3)=6",
            "生活中的例子": "速度是位移的导数、边际成本是总成本的导数。",
        },
        "积分": {
            "是什么": "导数的逆运算，求函数图像下的面积。",
            "符号": "∫f(x)dx = F(x)+C，其中 F'(x)=f(x)",
            "例子": "∫2xdx = x²+C",
            "生活中的例子": "求累积总量、概率分布下的面积。",
        },
        "三角恒等式": {
            "是什么": "三角函数之间的基本等量关系。",
            "符号": "sin²θ+cos²θ=1，tanθ=sinθ/cosθ",
            "例子": "sin²30°+cos²30° = (1/2)²+(√3/2)² = 1/4+3/4 = 1",
            "生活中的例子": "波形分析、振动计算。",
        },
        "对数法则": {
            "是什么": "对数运算的三条基本法则。",
            "符号": "log(ab)=log a+log b，log(a/b)=log a-log b，log(aⁿ)=n·log a",
            "例子": "log₂(8×4) = log₂8+log₂4 = 3+2 = 5",
            "生活中的例子": "科学计数法、分贝计算。",
        },
        # ── 统计与概率 ─────────────────────────────────────────────────────────
        "方差": {
            "是什么": "数据偏离平均值的程度，衡量数据的离散程度。",
            "符号": "σ² = Σ(xᵢ-μ)²/n",
            "例子": "[2,4,6] 平均=4，方差=(4+0+4)/3=2.67",
            "生活中的例子": "考试成绩稳定性、股票波动风险。",
        },
        "标准差": {
            "是什么": "方差的平方根，与原始数据单位一致。",
            "符号": "σ = √σ²",
            "例子": "方差=4，标准差=√4=2",
            "生活中的例子": "身高体重分布、产品质量控制。",
        },
        "排列": {
            "是什么": "从n个不同元素中取m个，按顺序排列。",
            "符号": "A(n,m) = n!/(n-m)!",
            "例子": "A(5,3) = 5!/(5-3)! = 120/2 = 60",
            "生活中的例子": "比赛排名、密码组合。",
        },
        "组合": {
            "是什么": "从n个不同元素中取m个，不考虑顺序。",
            "符号": "C(n,m) = n!/(m!×(n-m)!)",
            "例子": "C(5,3) = 5!/(3!×2!) = 10",
            "生活中的例子": "彩票组合、小组分组。",
        },
        "正态分布": {
            "是什么": "最常见的概率分布，呈钟形曲线，由均值和标准差决定。",
            "符号": "N(μ,σ²)，约68%数据在μ±σ内",
            "例子": "身高~N(170cm, 7cm)，约68%的人在163-177cm",
            "生活中的例子": "考试成绩分布、产品质量指标。",
        },
        # ── 应用数学 ─────────────────────────────────────────────────────────
        "速度时间距离": {
            "是什么": "匀速运动中，距离=速度×时间。",
            "符号": "d = v × t，v = d/t，t = d/v",
            "例子": "速度60km/h，2小时行驶 = 120km",
            "生活中的例子": "行程规划、跑步配速。",
        },
        "工作问题": {
            "是什么": "多人合作完成工作的问题，效率相加。",
            "符号": "总效率 = 效率1+效率2，时间 = 1/总效率",
            "例子": "甲3小时完成，乙6小时完成，合作=1/(1/3+1/6)=2小时",
            "生活中的例子": "团队分工、工期估算。",
        },
        "浓度问题": {
            "是什么": "溶液中溶质与溶液的质量比。",
            "符号": "浓度 = 溶质/溶液 × 100%",
            "例子": "10g盐溶在90g水，浓度=10/100=10%",
            "生活中的例子": "调配饮料、配制消毒液。",
        },
        # ── 高等数学入门 ───────────────────────────────────────────────────────
        "极限": {
            "是什么": "函数在某点附近的变化趋势。",
            "符号": "lim[x→a] f(x) = L",
            "例子": "lim[x→0] sin(x)/x = 1",
            "生活中的例子": "瞬时速度、微积分基础概念。",
        },
        "等差数列求和": {
            "是什么": "等差数列前n项和的计算方法。",
            "符号": "S_n = n(a₁+aₙ)/2 = na₁+n(n-1)d/2",
            "例子": "1+2+...+100 = 100×(1+100)/2 = 5050",
            "生活中的例子": "阶梯票价累计、等间距累加。",
        },
        "等比数列求和": {
            "是什么": "等比数列前n项和的计算方法。",
            "符号": "S_n = a₁(1-rⁿ)/(1-r)，|r|<1时S_∞=a₁/(1-r)",
            "例子": "1+1/2+1/4+... = 1/(1-1/2) = 2",
            "生活中的例子": "复利增长、几何级数衰减。",
        },
        # ── 数论与离散 ─────────────────────────────────────────────────────────
        "最大公约数": {
            "是什么": "两个数共有的最大因数。",
            "符号": "gcd(a,b)",
            "例子": "gcd(12,18) = 6",
            "生活中的例子": "约分分数、分配物品。",
        },
        "最小公倍数": {
            "是什么": "两个数共有的最小倍数。",
            "符号": "lcm(a,b) = a×b/gcd(a,b)",
            "例子": "lcm(4,6) = 24/2 = 12",
            "生活中的例子": "通分分数、周期同步。",
        },
        "质因数分解": {
            "是什么": "把一个合数分解为若干个质数的乘积。",
            "符号": "n = p₁^a₁ × p₂^a₂ × ...",
            "例子": "60 = 2²×3×5",
            "生活中的例子": "密码学、约分。",
        },
        # ── 几何进阶 ───────────────────────────────────────────────────────────
        "三角形面积": {
            "是什么": "底乘以高除以2。",
            "符号": "S = 底×高/2",
            "例子": "底6cm高4cm，面积=6×4/2=12cm²",
            "生活中的例子": "屋顶面积、布料裁剪。",
        },
        "球体积": {
            "是什么": "球的体积计算公式。",
            "符号": "V = 4/3 πr³",
            "例子": "半径3cm的球，V ≈ 4/3×3.14×27 ≈ 113cm³",
            "生活中的例子": "篮球体积、储油罐容量。",
        },
        "圆柱体积": {
            "是什么": "底面积乘以高。",
            "符号": "V = πr²h",
            "例子": "半径2cm高5cm的圆柱，V ≈ 3.14×4×5 ≈ 62.8cm³",
            "生活中的例子": "水杯容量、油桶体积。",
        },
    }

    def explain_concept(self, topic: str) -> dict:
        """讲解数学概念。"""
        for key, info in self.MATH_CONCEPTS.items():
            if key in topic or topic in key:
                return {"topic": key, **info}
        return {
            "topic": topic,
            "是什么": f"关于 '{topic}' 的概念",
            "例子": "请尝试输入：加法、乘法、除法、平方、开方、平均值、素数、三角函数",
        }

    # ── 待办事项管理 ─────────────────────────────────────────

    def create_task(self, title: str, steps: list[Step]) -> Task:
        """创建待办事项。"""
        task_id = f"task_{int(time.time() * 1000)}"
        task = Task(id=task_id, title=title, steps=steps)
        self._tasks[task_id] = task
        return task

    def get_task(self, task_id: str) -> Optional[Task]:
        return self._tasks.get(task_id)

    def list_tasks(self, status: Optional[str] = None) -> list[Task]:
        if status is None:
            return list(self._tasks.values())
        return [t for t in self._tasks.values() if t.status == status]

    def mark_done(self, task_id: str) -> bool:
        if task_id in self._tasks:
            self._tasks[task_id].status = "done"
            return True
        return False

    # ── 对话历史 ─────────────────────────────────────────────

    def add_message(self, msg: ChatMessage):
        self._messages.append(msg)

    def get_history(self, limit: int = 20) -> list[ChatMessage]:
        return self._messages[-limit:]

    # ── 常识推断 ──────────────────────────────────────────────

    def _decompose_commonsense(self, text: str, intent: IntentType) -> list[Step]:
        """当标准分解失败时，用常识推断生成步骤。"""
        nums = self.extract_numbers(text)
        text_lower = text.lower()
        _logger.debug("=== 常识推断开始: intent=%s text='%s' nums=%s ===", intent.value, text, nums)
        steps = []

        # 1. "帮我算一下" / "算算" 等泛化表达
        if any(kw in text_lower for kw in ["帮我算", "算算", "怎么算", "求一下", "算一算"]):
            if len(nums) >= 2:
                op = "+"
                if "减" in text_lower: op = "-"
                elif "乘" in text_lower or "倍" in text_lower: op = "*"
                elif "除" in text_lower or "一半" in text_lower: op = "/"
                _logger.debug("  [常识分支1] 泛化表达: op=%s", op)
                steps.append(Step(f"计算 {nums[0]} {op} {nums[1]}",
                                  f"#1：[{nums[0]} {op} {nums[1]}]",
                                  f"{nums[0]} {op} {nums[1]} = ?"))
            elif len(nums) == 1:
                n = nums[0]
                if "平方" in text_lower:
                    _logger.debug("  [常识分支1] 单数字→平方")
                    steps.append(Step(f"计算 {n} 的平方",
                                      f"#1：[{n} * {n}]", f"{n} 的平方 = {n} × {n}"))
                elif "阶乘" in text_lower or "!" in text_lower:
                    _logger.debug("  [常识分支1] 单数字→阶乘")
                    steps.append(Step(f"计算 {int(n)} 的阶乘",
                                      f"#1：[阶乘({int(n)})]", f"{int(n)}! = ?"))
                elif "根" in text_lower:
                    _logger.debug("  [常识分支1] 单数字→开方")
                    steps.append(Step(f"计算 {n} 的平方根",
                                      f"#1：[sqrt({n})]", f"√{n} = ?"))
            if steps:
                _logger.debug("  [常识分支1] 生成步骤: %s", [s.description for s in steps])
                return steps

        # 2. "一半" / "二分之一"
        if "一半" in text_lower or "二分之一" in text_lower:
            if nums:
                _logger.debug("  [常识分支2] 一半→除法: %s / 2", nums[0])
                steps.append(Step(f"计算 {nums[0]} 的一半",
                                  f"#1：[{nums[0]} / 2]", f"{nums[0]} ÷ 2 = ?"))
                return steps

        # 3. "倍" 相关
        if "倍" in text_lower:
            if len(nums) >= 2:
                _logger.debug("  [常识分支3] 倍→乘法: %s * %s", nums[0], nums[1])
                steps.append(Step(f"计算 {nums[0]} 的 {nums[1]} 倍",
                                  f"#1：[{nums[0]} * {nums[1]}]",
                                  f"{nums[0]} 的 {nums[1]} 倍 = {nums[0]} × {nums[1]}"))
                return steps

        # 4. 单位换算常见模式
        unit_map = {
            "千米": ("千米", "米", 1000.0), "公里": ("公里", "米", 1000.0),
            "米": ("米", "千米", 0.001), "厘米": ("厘米", "米", 0.01),
            "千克": ("千克", "克", 1000.0), "吨": ("吨", "千克", 1000.0),
            "华氏度": ("华氏度", "摄氏度", None), "摄氏度": ("摄氏度", "华氏度", None),
        }
        # 时间换算特殊处理
        time_map = {
            "秒": ("秒", "分", 60.0), "分": ("分", "小时", 60.0),
            "小时": ("小时", "天", 24.0), "天": ("天", "小时", 1.0/24.0),
        }
        for unit, (from_u, to_u, factor) in time_map.items():
            if unit in text_lower and nums:
                _logger.debug("  [常识分支4-time] 时间换算: %s %s → %s (÷%s)", nums[0], from_u, to_u, factor)
                steps.append(Step(f"{from_u}→{to_u}换算",
                                  f"#1：[{nums[0]} / {factor}]",
                                  f"{nums[0]} {from_u} = {nums[0]/factor} {to_u}"))
                return steps
        for unit, (from_u, to_u, factor) in unit_map.items():
            if unit in text_lower and nums:
                _logger.debug("  [常识分支4-unit] 单位换算: %s %s → %s (×%s)", nums[0], from_u, to_u, factor)
                steps.append(Step(f"{from_u}→{to_u}换算",
                                  f"#1：[换算_{from_u}_{to_u}({nums[0]})]",
                                  f"{nums[0]} {from_u} = ? {to_u}"))
                return steps

        # 5. 纯数字 → 猜测算术
        if nums and not steps:
            _logger.debug("  [常识分支5] 纯数字兜底: nums=%s", nums)
            if len(nums) >= 2:
                steps.append(Step(f"计算 {nums[0]} 与 {nums[1]} 的关系",
                                  f"#1：[{nums[0]} + {nums[1]}]",
                                  f"两个数 {nums[0]} 和 {nums[1]}，尝试加法"))
            elif len(nums) == 1:
                n = nums[0]
                if n == int(n):
                    n_int = int(n)
                    steps.append(Step(f"分析数字 {n_int}",
                                      f"#1：[阶乘({n_int})]",
                                      f"数字 {n_int}，尝试阶乘运算"))

        return steps

    def _try_alternative(self, text: str, intent: IntentType) -> list[Step]:
        """当首选方案失败时，尝试替代方案。"""
        nums = self.extract_numbers(text)
        text_lower = text.lower()
        _logger.debug("=== 替代方案尝试: intent=%s text='%s' nums=%s ===", intent.value, text, nums)

        # 替代方案1：如果是算术但加法失败，试其他运算
        if intent == IntentType.算术 and nums:
            alternatives = []
            if len(nums) >= 2:
                for op_name, op_sym, op_func in [
                    ("乘法", "*", lambda a,b: a*b),
                    ("除法", "/", lambda a,b: a/b if b else None),
                    ("减法", "-", lambda a,b: a-b),
                    ("幂运算", "^", lambda a,b: a**b),
                ]:
                    try:
                        r = op_func(nums[0], nums[1])
                        if r is not None:
                            _logger.debug("  [替代方案1] %s: %s %s %s = %s",
                                         op_name, nums[0], op_sym, nums[1], r)
                            alternatives.append(Step(
                                f"替代方案：{op_name}",
                                f"#1：[{nums[0]} {op_sym} {nums[1]}]",
                                f"{op_name}：{nums[0]} {op_sym} {nums[1]} = {r}"))
                    except (ZeroDivisionError, ValueError) as e:
                        _logger.debug("  [替代方案1] %s 失败: %s", op_name, e)
            _logger.debug("  [替代方案1] 共生成 %d 个替代步骤", len(alternatives))
            return alternatives

        # 替代方案2：物理计算 — 如果数字像时间，试自由落体
        if intent == IntentType.物理 and nums:
            t = nums[0]
            _logger.debug("  [替代方案2] 物理→自由落体: t=%.1f", t)
            return [Step("替代：自由落体",
                         f"#1：[运动_自由落体位移({t})]",
                         f"尝试自由落体计算，时间 {t} 秒")]

        return []


# ============================================================
# 主控制器
# ============================================================

class MathaAIAssistant:
    """Matha AI 助手 — 小白友好型数学计算平台。"""

    def __init__(self):
        self.parser = FriendlyIntentParser()
        self._history: list[dict] = []
        # ── 新功能模块 ─────────────────────────────────────────────────────
        self.symbolic = None
        self.ffi = None
        self.paradigm = None
        self.codegen = None
        self.drivers = None
        if _NEW_MODULES_LOADED:
            try:
                self.symbolic = SymbolicParser()
                self.ffi = get_ffi()
                self.paradigm = get_paradigm_engine()
                self.codegen = get_codegen()
                self.drivers = get_driver_manager()
                _logger.info("  新功能模块已加载: 符号引擎/FFI/多范式/代码生成/驱动")
            except Exception as e:
                _logger.warning(f"  新功能模块初始化失败: {e}")

    def chat(self, text: str, interp=None) -> dict:
        """
        处理用户输入，返回结构化响应。

        返回:
          {
            "reply": str,          # 给用户的回复
            "code": str,           # 生成的 Matha 代码
            "steps": list,         # 分解步骤
            "result": Any,         # 执行结果
            "explanation": str,    # 结果解释
            "type": str            # text / error / task
          }
        """
        _logger.info("=== chat 入口: '%s' ===", text)

        text = text.strip()
        if not text:
            return {"reply": "请输入你的问题，例如：'计算 3 加 5'", "type": "text"}

        # 1. 分类意图（多策略增强）
        intent_type, confidence = self.parser.classify(text)
        _logger.info("  意图分类: %s (置信度 %.0f%%)", intent_type.value, confidence * 100)

        # 2. 分解步骤（增强版：多路径尝试）
        steps = self.parser.decompose(text)
        _logger.info("  标准分解: %d 步", len(steps))
        if not steps or (len(steps) == 1 and not steps[0].matha_code):
            # 分解失败 → 尝试常识推断
            _logger.info("  标准分解失败，触发常识推断")
            steps = self.parser._decompose_commonsense(text, intent_type)
            _logger.info("  常识推断: %d 步", len(steps))

        # 3. 生成代码
        code_lines = []
        for step in steps:
            if step.matha_code:
                code_lines.append(step.matha_code)

        matha_code = "\n".join(code_lines) if code_lines else ""
        _logger.info("  生成代码: %s", matha_code[:80] if matha_code else "(空)")

        # 4. 执行
        result = None
        error = None
        if matha_code and interp:
            try:
                from src.parser import parse
                from src.interp import Interpreter
                i = interp or Interpreter()
                outputs, _ = i.run(parse(matha_code))
                result = outputs[-1] if outputs else None
                _logger.info("  执行成功: result=%s", result)
            except Exception as e:
                error = str(e)
                _logger.warning("  执行失败: %s", error)
                # 执行失败 → 尝试替代方案
                if not matha_code or not result:
                    alt_steps = self.parser._try_alternative(text, intent_type)
                    if alt_steps and alt_steps[0].matha_code:
                        _logger.info("  尝试替代方案: %s", alt_steps[0].description)
                        try:
                            alt_code = alt_steps[0].matha_code
                            outputs2, _ = i.run(parse(alt_code))
                            result = outputs2[-1] if outputs2 else None
                            steps = alt_steps
                            _logger.info("  替代方案成功: result=%s", result)
                        except Exception as e2:
                            _logger.warning("  替代方案也失败: %s", e2)

        # 5. 生成回复
        if error:
            explanation = self.parser.explain_error(error)
            reply = (
                f"⚠️ 遇到问题：{explanation['what']}\n\n"
                f"💡 怎么修：{explanation['how']}\n\n"
                f"📝 示例：\n{explanation['example']}"
            )
            return {
                "reply": reply,
                "code": matha_code,
                "steps": [s.description for s in steps],
                "result": None,
                "explanation": explanation,
                "type": "error",
                "intent": intent_type.value,
                "confidence": round(confidence, 2),
            }

        if result is not None:
            reply = (
                f"✅ 计算结果：{result}\n\n"
                f"📋 分解步骤：\n" +
                "\n".join(f"  {i+1}. {s.description}" for i, s in enumerate(steps))
            )
            return {
                "reply": reply,
                "code": matha_code,
                "steps": [s.description for s in steps],
                "result": result,
                "explanation": steps[0].explanation if steps else "",
                "type": "result",
                "intent": intent_type.value,
                "confidence": round(confidence, 2),
            }

        # 无结果，给出引导
        reply = (
            f"🤔 我理解你的意图是「{intent_type.value}」"
            f"（置信度 {confidence:.0%}）\n\n"
            f"📝 可以这样表达：\n"
            f"  • '计算 3 加 5'\n"
            f"  • '找出 1 到 100 的素数'\n"
            f"  • '计算 5 的阶乘'\n"
            f"  • '自由落体 3 秒'\n"
            f"  • '求 [1,2,3,4,5] 的平均值'"
        )
        _logger.info("  最终返回 guide 类型")
        return {
            "reply": reply,
            "code": "",
            "steps": [s.description for s in steps],
            "result": None,
            "explanation": "",
            "type": "guide",
            "intent": intent_type.value,
            "confidence": round(confidence, 2),
        }

    def get_growth_report(self) -> dict:
        """返回成长分析报告。"""
        return self.parser.get_growth_stats()

    def help(self) -> str:
        return """
🎯 Matha AI 助手使用指南
━━━━━━━━━━━━━━━━━━━━━━━━
模式 1：直接计算
  输入：计算 3 加 5
  输入：求 100 的平方根

模式 2：统计运算
  输入：求 [1,2,3,4,5] 的平均值
  输入：找出这组数的最大值

模式 3：物理计算
  输入：自由落体 3 秒
  输入：斜抛 30度，速度 20

模式 4：数论
  输入：找出 1 到 100 的素数
  输入：5 的阶乘是多少

模式 5：数学概念
  输入：什么是素数
  输入：解释三角函数

模式 6：查看帮助
  输入：help
  输入：模式切换 nl/intent
"""
