@echo off
REM Matha WASM 一键构建脚本 (Windows)
REM 用法: build_wasm.bat [--skip-deps] [--dry-run]

setlocal enabledelayedexpansion

echo ============================================================
echo   Matha WASM 构建脚本 v3.0
echo ============================================================
echo.

REM 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到 Python，请先安装 Python 3.10+
    exit /b 1
)

echo [步骤 1] 检查并安装依赖...
pip show pyodide-build >nul 2>&1
if errorlevel 1 (
    echo   安装 pyodide-build...
    pip install pyodide-build setuptools --quiet
    if errorlevel 1 (
        echo [警告] pyodide-build 安装失败，将尝试手动构建
    )
) else (
    echo   pyodide-build 已安装
)

pip show setuptools >nul 2>&1
if errorlevel 1 (
    echo   安装 setuptools...
    pip install setuptools --quiet
)

echo.
echo [步骤 2] 生成包定义文件...
python matha_wasm\build_wasm.py %*

echo.
echo [步骤 3] 检查构建产物...
if exist matha_wasm\dist (
    echo   dist 目录已存在
    dir matha_wasm\dist\*.whl 2>nul
    if errorlevel 1 (
        echo   [提示] 未找到 .whl 文件，需要安装 micromamba 后执行 pyodide build
    )
) else (
    echo   [提示] dist 目录不存在
)

echo.
echo ============================================================
echo   构建完成
echo ============================================================
echo.
echo 下一步:
echo   1. 安装 micromamba: https://mamba.readthedocs.io/en/latest/installation/micromamba-installation.html
echo   2. 创建环境: micromamba create -n matha-wasm -c conda-forge pyodide
echo   3. 激活环境: micromamba activate matha-wasm
echo   4. 构建: cd matha_wasm && pyodide build --output dist/
echo   5. 部署 WHL 到 HTTP 服务器供 Flutter 加载
echo.
pause
