# -*- coding: utf-8 -*-
"""将 Matha 打包为 Pyodide WASM 包。"""
import shutil
from pathlib import Path

BASE = Path(__file__).parent.parent
WASM_SRC = BASE / "matha_wasm"
WASM_SRC.mkdir(exist_ok=True)

# 创建 pyproject.toml
(WASM_SRC / "pyproject.toml").write_text("""\
[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.backends._legacy:_Backend"

[project]
name = "matha"
version = "2.4.0"
description = "Matha 自成长编程语言解释器"
requires-python = ">=3.8"
dependencies = ["numpy>=1.24"]

[tool.setuptools.packages.find]
where = ["src"]
""", encoding="utf-8")

# 创建 package.yaml
(WASM_SRC / "package.yaml").write_text("""\
source:
  path: .

requirements:
  python:
    - numpy

test:
  imports:
    - src
  scripts:
    - tests/test_wasm_smoke.py

about:
  homepage: https://github.com/example/matha
  license: MIT
""", encoding="utf-8")

# 复制 src 目录
src_dir = WASM_SRC / "src"
if src_dir.exists():
    shutil.rmtree(src_dir)
shutil.copytree(
    BASE / "src", src_dir,
    ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "hardware", "compiler"),
)

print(f"WASM 包定义已生成: {WASM_SRC}")
print(f"请运行: pyodide build --output dist/  (在 {WASM_SRC} 目录下)")
