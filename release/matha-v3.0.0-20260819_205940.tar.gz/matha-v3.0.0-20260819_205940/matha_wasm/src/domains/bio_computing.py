# -*- coding: utf-8 -*-
"""生物计算领域：基因组学、蛋白质分析、系统生物学。"""
from __future__ import annotations
import math

# 遗传密码表
GENETIC_CODE = {
    "ATA":"I", "ATC":"I", "ATT":"I", "ATG":"M",
    "ACA":"T", "ACC":"T", "ACG":"T", "ACT":"T",
    "AAC":"N", "AAT":"N", "AAA":"K", "AAG":"K",
    "AGC":"S", "AGT":"S", "AGA":"R", "AGG":"R",
    "CTA":"L", "CTC":"L", "CTG":"L", "CTT":"L",
    "CCA":"P", "CCC":"P", "CCG":"P", "CCT":"P",
    "CAC":"H", "CAT":"H", "CAA":"Q", "CAG":"Q",
    "CGA":"R", "CGC":"R", "CGG":"R", "CGT":"R",
    "GTA":"V", "GTC":"V", "GTG":"V", "GTT":"V",
    "GCA":"A", "GCC":"A", "GCG":"A", "GCT":"A",
    "GAC":"D", "GAT":"D", "GAA":"E", "GAG":"E",
    "GGC":"G", "GGT":"G", "GGG":"G",
    "TCA":"S", "TCC":"S", "TCG":"S", "TCT":"S",
    "TTC":"F", "TTT":"F", "TTA":"L", "TTG":"L",
    "TAC":"Y", "TAT":"Y", "TAA":"*", "TAG":"*",
    "TGC":"C", "TGT":"C", "TGA":"*", "TGG":"W",
}

# ─── 分子生物学 ───────────────────────────────────────────

def dna_translate(dna: str) -> str:
    """DNA → 蛋白质（通过 mRNA 中转）。"""
    rna = dna.replace("T", "U")
    protein = ""
    for i in range(0, len(rna) - 2, 3):
        codon = rna[i:i+3]
        protein += GENETIC_CODE.get(codon, "X")
    return protein

def rna_fold(rna: str) -> str:
    """RNA 二级结构预测（简化：碱基配对数）。"""
    comp = {"A": "U", "U": "A", "G": "C", "C": "G"}
    folded = ""
    for base in rna:
        folded += comp.get(base, base)
    return folded[::-1]

def gc_content(seq: str) -> float:
    """GC 含量。"""
    if not seq:
        return 0.0
    gc = sum(1 for c in seq.upper() if c in "GC")
    return gc / len(seq)

def protein_mass(seq: str) -> float:
    """蛋白质分子量估算（平均残基质量 110 Da）。"""
    return len(seq) * 110.0

def isoelectric_point(seq: str) -> float:
    """等电点简化估算。"""
    acidic = sum(1 for c in seq if c in "DE")
    basic = sum(1 for c in seq if c in "KRH")
    return 6.0 + 0.5 * (basic - acidic)

# ─── 系统生物学 ───────────────────────────────────────────

def metabolic_flux(Vmax: float, Km: float, S: float) -> float:
    """代谢通量（米氏方程）。"""
    return Vmax * S / (Km + S)

def enzyme_kinetics(Vmax: float, Km: float, S: float) -> float:
    """酶动力学（同米氏方程）。"""
    return Vmax * S / (Km + S)

def population_growth(N0: float, r: float, t: float) -> float:
    """指数种群增长。"""
    return N0 * math.exp(r * t)

def epidemic_sir(S0: float, I0: float, R0: float, beta: float, gamma: float, t: float) -> dict:
    """SIR 流行病模型。"""
    S, I, R = S0, I0, R0
    N = S + I + R
    dt = 0.01
    steps = int(t / dt)
    for _ in range(steps):
        dS = -beta * S * I / N * dt
        dI = beta * S * I / N * dt - gamma * I * dt
        dR = gamma * I * dt
        S += dS
        I += dI
        R += dR
    return {"S": S, "I": I, "R": R, "R0": beta / gamma if gamma > 0 else float("inf")}

def phylogenetic_distance(seq1: str, seq2: str) -> float:
    """系统发育距离（p-distance）。"""
    if len(seq1) != len(seq2):
        return float("nan")
    diffs = sum(1 for a, b in zip(seq1, seq2) if a != b)
    return diffs / len(seq1)

__all__ = ["dna_translate", "rna_fold", "gc_content", "protein_mass",
           "isoelectric_point", "metabolic_flux", "enzyme_kinetics",
           "population_growth", "epidemic_sir", "phylogenetic_distance"]
