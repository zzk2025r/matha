#!/bin/bash
# Matha WASM 一键构建脚本 (Linux/macOS)
# 用法: ./build_wasm.sh [--skip-deps] [--dry-run]

set -e

echo "============================================================"
echo "  Matha WASM 构建脚本 v3.0"
echo "============================================================"
echo ""

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "[错误] 未找到 Python3，请先安装 Python 3.10+"
    exit 1
fi

echo "[步骤 1] 检查并安装依赖..."
pip3 show pyodide-build &> /dev/null
if [ $? -ne 0 ]; then
    echo "  安装 pyodide-build..."
    pip3 install pyodide-build setuptools --quiet
fi

pip3 show setuptools &> /dev/null
if [ $? -ne 0 ]; then
    echo "  安装 setuptools..."
    pip3 install setuptools --quiet
fi

echo ""
echo "[步骤 2] 生成包定义文件..."
python3 matha_wasm/build_wasm.py "$@"

echo ""
echo "[步骤 3] 检查构建产物..."
if [ -d "matha_wasm/dist" ]; then
    echo "  dist 目录已存在"
    ls -lh matha_wasm/dist/*.whl 2>/dev/null || echo "  [提示] 未找到 .whl 文件"
else
    echo "  [提示] dist 目录不存在"
fi

echo ""
echo "============================================================"
echo "  构建完成"
echo "============================================================"
echo ""
echo "下一步:"
echo "  1. 安装 micromamba: https://mamba.readthedocs.io/"
echo "  2. 创建环境: micromamba create -n matha-wasm -c conda-forge pyodide"
echo "  3. 激活环境: micromamba activate matha-wasm"
echo "  4. 构建: cd matha_wasm && pyodide build --output dist/"
echo "  5. 部署 WHL 到 HTTP 服务器供 Flutter 加载"
echo ""
