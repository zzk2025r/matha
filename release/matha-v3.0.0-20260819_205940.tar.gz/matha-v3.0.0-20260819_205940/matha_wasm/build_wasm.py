# -*- coding: utf-8 -*-
"""Matha WASM 自动构建脚本。

功能：
  1. 自动检测并安装 pyodide-build / setuptools
  2. 生成 matha_wasm 包定义（pyproject.toml + package.yaml）
  3. 复制 src 目录到 matha_wasm/src/
  4. 执行 pyodide build 生成 .whl 文件
  5. 输出构建报告

用法：
    python matha_wasm/build_wasm.py              # 完整构建
    python matha_wasm/build_wasm.py --skip-deps  # 跳过依赖安装
    python matha_wasm/build_wasm.py --dry-run    # 仅检查环境
"""
import os
import sys
import shutil
import subprocess
import argparse
import platform
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent
MATHA_WASM_DIR = PROJECT_ROOT / "matha_wasm"
SRC_DIR = PROJECT_ROOT / "src"
DIST_DIR = MATHA_WASM_DIR / "dist"


def log(msg: str, level: str = "INFO") -> None:
    prefix = {"INFO": "✅", "WARN": "⚠️", "ERROR": "❌", "STEP": "▶️"}.get(level, "  ")
    print(f"  {prefix} {msg}")


def run_cmd(cmd: list[str], cwd: Path | None = None, capture: bool = False) -> tuple[int, str]:
    """运行命令，返回 (exit_code, output)。"""
    log(f"$ {' '.join(cmd)}", "STEP")
    try:
        result = subprocess.run(
            cmd, cwd=cwd or PROJECT_ROOT,
            capture_output=capture, text=True, timeout=300
        )
        return result.returncode, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return -1, "超时（300s）"
    except FileNotFoundError:
        return -1, f"命令未找到: {cmd[0]}"


def check_python() -> bool:
    """检查 Python 版本。"""
    log(f"Python {sys.version.split()[0]}")
    if sys.version_info < (3, 10):
        log("需要 Python 3.10+", "ERROR")
        return False
    return True


def install_dependencies(skip: bool = False) -> bool:
    """安装 pyodide-build 和 setuptools。"""
    if skip:
        log("跳过依赖安装 (--skip-deps)", "WARN")
        return True

    log("检查并安装依赖...")
    deps = ["pyodide-build", "setuptools"]
    for dep in deps:
        try:
            __import__(dep.replace("-", "_"))
            log(f"{dep} 已安装")
        except ImportError:
            log(f"安装 {dep}...")
            ret, out = run_cmd([sys.executable, "-m", "pip", "install", dep, "--quiet"])
            if ret == 0:
                log(f"{dep} 安装成功")
            else:
                log(f"{dep} 安装失败 (exit={ret})", "ERROR")
                log(out[-500:] if out else "", "ERROR")
                return False
    return True


def check_pyodide_cli() -> bool:
    """检查 pyodide CLI 是否可用。"""
    ret, _ = run_cmd(["pyodide", "--version"])
    if ret == 0:
        log("pyodide CLI 可用")
        return True
    # 尝试通过模块调用
    ret2, _ = run_cmd([sys.executable, "-m", "pyodide_build", "--help"])
    if ret2 == 0:
        log("pyodide_build 模块可用")
        return True
    log("pyodide CLI 不可用，尝试通过 python -m 方式构建", "WARN")
    return False


def generate_package_files() -> bool:
    """生成 matha_wasm 包定义文件。"""
    log("生成包定义文件...")

    # pyproject.toml
    pyproject = MATHA_WASM_DIR / "pyproject.toml"
    pyproject.write_text("""\
[build-system]
requires = ["setuptools>=64", "wheel"]
build-backend = "setuptools.backends._legacy:_Backend"

[project]
name = "matha-core"
version = "3.0.0"
description = "Matha 核心领域库 - WASM 构建"
requires-python = ">=3.10"
dependencies = []

[tool.setuptools.packages.find]
where = ["src"]
include = ["src.domains*"]
""", encoding="utf-8")

    # package.yaml (Pyodide 描述)
    package_yaml = MATHA_WASM_DIR / "package.yaml"
    package_yaml.write_text("""\
# Pyodide package description for matha-core
package:
  name: matha-core
  version: "3.0.0"
  build:
    script: setup.py
  requirements:
    python: []
  test:
    imports:
      - src.domains
""", encoding="utf-8")

    # setup.py
    setup_py = MATHA_WASM_DIR / "setup.py"
    setup_py.write_text("""\
from setuptools import setup, find_packages
setup(
    name="matha-core",
    version="3.0.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
)
""", encoding="utf-8")

    log("包定义文件生成完成")
    return True


def copy_source() -> bool:
    """复制 src 目录到 matha_wasm/src/。"""
    log("复制源文件...")
    dest = MATHA_WASM_DIR / "src"
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(SRC_DIR, dest, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    # 复制 domains 目录
    domains_src = SRC_DIR / "domains"
    domains_dst = dest / "domains"
    if domains_dst.exists():
        shutil.rmtree(domains_dst)
    shutil.copytree(domains_src, domains_dst)
    log(f"已复制 {len(list(dest.rglob('*.py')))} 个 Python 文件")
    return True


def build_wasm(dry_run: bool = False) -> bool:
    """执行 WASM 构建。"""
    if dry_run:
        log("dry-run 模式，跳过构建", "WARN")
        return True

    # 方法1: pyodide build
    log("尝试 pyodide build...")
    ret, out = run_cmd([
        sys.executable, "-m", "pyodide_build", "build",
        str(MATHA_WASM_DIR), "--output", str(DIST_DIR)
    ])

    if ret == 0:
        log("WASM 构建成功")
        whl_files = list(DIST_DIR.glob("*.whl"))
        for f in whl_files:
            log(f"生成的 wheel: {f.name} ({f.stat().st_size / 1024:.1f} KB)")
        return True

    # 方法2: 直接 python setup.py bdist_wheel
    log("pyodide build 失败，尝试 setuptools wheel...", "WARN")
    ret2, out2 = run_cmd([
        sys.executable, "setup.py", "bdist_wheel", "-d", str(DIST_DIR)
    ], cwd=MATHA_WASM_DIR)

    if ret2 == 0:
        log("wheel 构建成功（非 WASM）")
        whl_files = list(DIST_DIR.glob("*.whl"))
        for f in whl_files:
            log(f"生成的 wheel: {f.name} ({f.stat().st_size / 1024:.1f} KB)")
        log("注意: 这是普通 wheel，不是 WASM 包。需安装 pyodide-build 后重试。", "WARN")
        return True

    log(f"构建失败 (exit={ret2})", "ERROR")
    log(out2[-1000:] if out2 else "无输出", "ERROR")
    return False


def generate_report(success: bool) -> None:
    """生成构建报告。"""
    report_lines = [
        "=" * 60,
        "Matha WASM 构建报告",
        "=" * 60,
        f"时间: {__import__('datetime').datetime.now().isoformat()}",
        f"平台: {platform.system()} / {platform.machine()}",
        f"Python: {sys.version.split()[0]}",
        "",
        "状态:",
        f"  依赖安装: {'成功' if success else '失败'}",
        f"  包定义生成: {'成功' if success else '失败'}",
        f"  源文件复制: {'成功' if success else '失败'}",
        f"  WASM 构建: {'成功' if success else '待手动执行'}",
        "",
        "输出目录:",
        f"  {MATHA_WASM_DIR}",
        "",
        "下一步:",
        "  1. 安装 pyodide: micromamba install -c conda-forge pyodide",
        "  2. 执行构建: cd matha_wasm && pyodide build --output dist/",
        "  3. 在 Flutter 中加载: pyodide.loadPackage('http://localhost/matha-core-3.0.0-py3-none-any.whl')",
        "=" * 60,
    ]
    report_text = "\n".join(report_lines)
    print(report_text)

    # 保存到文件
    report_file = PROJECT_ROOT / "docs" / "WASM_BUILD_LOG.md"
    report_file.write_text(report_text, encoding="utf-8")
    log(f"报告已保存: {report_file}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Matha WASM 自动构建脚本")
    parser.add_argument("--skip-deps", action="store_true", help="跳过依赖安装")
    parser.add_argument("--dry-run", action="store_true", help="仅检查环境，不执行构建")
    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("  Matha WASM 自动构建脚本 v3.0")
    print("=" * 60 + "\n")

    # 1. 检查 Python
    if not check_python():
        sys.exit(1)

    # 2. 安装依赖
    if not install_dependencies(args.skip_deps):
        log("依赖安装失败，请手动安装: pip install pyodide-build setuptools", "ERROR")
        sys.exit(1)

    # 3. 检查 pyodide CLI
    has_cli = check_pyodide_cli()

    # 4. 生成包文件
    if not generate_package_files():
        sys.exit(1)

    # 5. 复制源文件
    if not args.dry_run and not copy_source():
        sys.exit(1)

    # 6. 构建
    if args.dry_run:
        log("dry-run 模式完成")
        return

    success = build_wasm()
    generate_report(success)

    if not success:
        log("\n请手动安装 pyodide-build 后重试：")
        log("  pip install pyodide-build setuptools")
        log("  cd matha_wasm && pyodide build --output dist/")
        sys.exit(1)


if __name__ == "__main__":
    main()
